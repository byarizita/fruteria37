<?php include_once "includes/header.php"; ?>

<div class="container-fluid">
  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800" id="pageTitle"></h1>
  </div>

  <!-- Content Row -->
  <div class="row">
    <!-- Earnings (Monthly) Card Example -->
    <a class="col-xl-3 col-md-6 mb-4" href="lista_usuarios.php">
      <div class="card border-left-primary shadow h-100 py-2 bg-white">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Usuarios</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800" id="usuariosCount"></div>
            </div>
            <div class="col-auto">
              <i class="fas fa-user fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </a>

    <!-- Earnings (Monthly) Card Example -->
    <a class="col-xl-3 col-md-6 mb-4" href="lista_cliente.php">
      <div class="card border-left-success shadow h-100 py-2 bg-white">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Clientes</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800" id="clientesCount"></div>
            </div>
            <div class="col-auto">
              <i class="fas fa-users fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </a>

    <!-- Earnings (Monthly) Card Example -->
    <a class="col-xl-3 col-md-6 mb-4" href="lista_productos.php">
      <div class="card border-left-info shadow h-100 py-2 bg-white">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Productos</div>
              <div class="row no-gutters align-items-center">
                <div class="col-auto">
                  <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" id="productosCount"></div>
                </div>
                <div class="col">
                  <div class="progress progress-sm mr-2">
                    <div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-auto">
              <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </a>

    <!-- Pending Requests Card Example -->
    <a class="col-xl-3 col-md-6 mb-4" href="ventas.php">
      <div class="card border-left-warning bg-white shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Ventas</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800" id="ventasCount"></div>
            </div>
            <div class="col-auto">
              <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </a>
    <div class="col-lg-6">
      <div class="au-card m-b-30">
        <div class="au-card-inner">
          <h3 class="title-2 m-b-40" id="stockMinTitle"></h3>
          <canvas id="sales-chart"></canvas>
        </div>
      </div>
    </div>
    <div class="col-lg-6">
      <div class="au-card m-b-30">
        <div class="au-card-inner">
          <h3 class="title-2 m-b-40" id="topProductsTitle"></h3>
          <canvas id="polarChart"></canvas>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  const pageTitle = document.getElementById('pageTitle');
  const usuariosCount = document.getElementById('usuariosCount');
  const clientesCount = document.getElementById('clientesCount');
  const productosCount = document.getElementById('productosCount');
  const ventasCount = document.getElementById('ventasCount');
  const stockMinTitle = document.getElementById('stockMinTitle');
  const topProductsTitle = document.getElementById('topProductsTitle');

  // Asigna el innerHTML
  pageTitle.innerHTML = 'Panel de Administración';
  usuariosCount.innerHTML = '<?php echo $data['usuarios']; ?>';
  clientesCount.innerHTML = '<?php echo $data['clientes']; ?>';
  productosCount.innerHTML = '<?php echo $data['productos']; ?>';
  ventasCount.innerHTML = '<?php echo $data['ventas']; ?>';
  stockMinTitle.innerHTML = 'Productos con stock mínimo';
  topProductsTitle.innerHTML = 'Productos más vendidos';
</script>


<?php include_once "includes/footer.php"; ?>