<?php
	date_default_timezone_set('America/Mexico_City');

	function fechaMexico()
	{
		$mes = array(
			"",
			"Enero",
			"Febrero",
			"Marzo",
			"Abril",
			"Mayo",
			"Junio",
			"Julio",
			"Agosto",
			"Septiembre",
			"Octubre",
			"Noviembre",
			"Diciembre"
		);
		return date('d') . " de " . $mes[date('n')] . " de " . date('Y');
	}
	
	function horaMexico()
	{
		$hora = date('h');
		$minutos = date('i');
		$segundos = date('s');
	
		return $hora . ":" . $minutos . ":" . $segundos;
	}
 ?>
